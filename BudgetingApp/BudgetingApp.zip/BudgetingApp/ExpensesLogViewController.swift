//
//  ExpensesLogViewController.swift
//  BudgetingApp
//
//  Created by Janice Jung on 11/20/19.
//  Copyright © 2019 Janice Jung. All rights reserved.
//

import UIKit

class ExpensesLogViewController: UIViewController {
    
    var categoryCollectionView: UICollectionView!
    var expenseCollectionView: UICollectionView!
    
    let CategoryCellReuseIdentifier = "categoryCellReuseIdentifier"
    let ExpenseCellReuseIdentifier = "expenseCellReuseIdentifier"
    
    var expenses: [Expense] = []
    var categories: [String] = []
    var selectedCategory: String?

    override func viewDidLoad() {
        super.viewDidLoad()
        
        view.backgroundColor = .white
        title = "Expenses"
        
        let expense1 = Expense(category: "Food", amount: "14", note: "Farmer's market")
        let expense2 = Expense(category: "Food", amount: "30", note: "Oyster bar")
        let expense3 = Expense(category: "Entertainment", amount: "20", note: "Movie")
        let expense4 = Expense(category: "Bills", amount: "100", note: "Phone bill")
        let expense5 = Expense(category: "Groceries", amount: "60", note: "Target run!")
        let expense6 = Expense(category: "Groceries", amount: "30", note: "Annabel's")
        let expense7 = Expense(category: "Shop", amount: "500", note: "Black friday  shopping")
        let expense8 = Expense(category: "Transport", amount: "10", note: "Gas")
        let expense9 = Expense(category: "Other", amount: "40", note: "Parking ticket")
        let expense10 = Expense(category: "Other", amount: "20", note: "Donations")
        
        expenses = [expense1, expense2, expense3, expense4, expense5, expense6, expense7, expense8, expense9, expense10]
        
        categories = ["Food", "Entertainment", "Bills", "Groceries", "Shop", "Transport", "Other"]
        
        let categoryLayout = UICollectionViewFlowLayout()
        categoryLayout.scrollDirection = .horizontal
        categoryLayout.minimumLineSpacing = CGFloat(8)
        categoryLayout.minimumInteritemSpacing = CGFloat(8)

        
        let expenseLayout = UICollectionViewFlowLayout()
        expenseLayout.scrollDirection = .vertical
        expenseLayout.minimumLineSpacing = CGFloat(8)
        expenseLayout.minimumInteritemSpacing = CGFloat(8)
        
        categoryCollectionView = UICollectionView(frame: .zero, collectionViewLayout: categoryLayout)
        categoryCollectionView.backgroundColor = .white
        categoryCollectionView.register(CategoryCollectionViewCell.self, forCellWithReuseIdentifier: CategoryCellReuseIdentifier)
        categoryCollectionView.showsHorizontalScrollIndicator = false
        categoryCollectionView.dataSource = self
        categoryCollectionView.delegate = self
        view.addSubview(categoryCollectionView)
        
        expenseCollectionView = UICollectionView(frame: .zero, collectionViewLayout: expenseLayout)
        expenseCollectionView.backgroundColor = .white
        expenseCollectionView.register(ExpenseCollectionViewCell.self, forCellWithReuseIdentifier: ExpenseCellReuseIdentifier)
        expenseCollectionView.showsVerticalScrollIndicator = false
        expenseCollectionView.dataSource = self
        expenseCollectionView.delegate = self
        view.addSubview(expenseCollectionView)
        
        setupConstraints()
    }
    
    func setupConstraints() {
        categoryCollectionView.snp.makeConstraints { make in
            make.top.left.right.equalTo(view.safeAreaLayoutGuide).inset(UIEdgeInsets(top:20, left: 20, bottom: 20, right: 20))
            make.height.equalTo(40)
            
        }
        
        expenseCollectionView.snp.makeConstraints { make in
            make.left.right.bottom.equalTo(view.safeAreaLayoutGuide).inset(UIEdgeInsets(top: 0, left: 20, bottom: 20, right: 20))
            make.top.equalTo(categoryCollectionView.snp.bottom).offset(20)
        }
    }


}

extension ExpensesLogViewController: UICollectionViewDelegate, UICollectionViewDataSource {
    
    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        if collectionView == categoryCollectionView {
            return categories.count
        } else {
            return expenses.count
        }
    }
    
    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
        
        if collectionView == categoryCollectionView {
            let category = categories[indexPath.row]
            let cell = categoryCollectionView.dequeueReusableCell(withReuseIdentifier: CategoryCellReuseIdentifier, for: indexPath) as! CategoryCollectionViewCell
            cell.configure(for: category)
            return cell
            
        } else {
            let expense = expenses[indexPath.row]
            let cell = expenseCollectionView.dequeueReusableCell(withReuseIdentifier: ExpenseCellReuseIdentifier, for: indexPath) as! ExpenseCollectionViewCell
            
            if let selected = selectedCategory {
                if expense.category == selected {
                    cell.configure(for: expense)
                }
            } else {
                cell.configure(for: expense)
            }
            
            return cell
        }
    }
    
    func collectionView(_ collectionView: UICollectionView, didSelectItemAt indexPath: IndexPath) {
        if collectionView == categoryCollectionView {
            let selectedCell = categoryCollectionView.cellForItem(at: indexPath) as! CategoryCollectionViewCell
            let category = categories[indexPath.row]
            if selectedCategory != category {
                selectedCategory = category
            } else {
                selectedCategory = nil
            }
            expenseCollectionView.reloadData()
        }
    }
    
}

extension ExpensesLogViewController: UICollectionViewDelegateFlowLayout {
    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, sizeForItemAt indexPath: IndexPath) -> CGSize {
       
        if collectionView == categoryCollectionView {
            let label = UILabel(frame: CGRect.zero)
            label.text = categories[indexPath.row]
            label.sizeToFit()
            return CGSize(width: label.frame.width+20, height: 32)
        } else {
           let width = collectionView.frame.width
           return CGSize(width: width, height: 200)
        }
    }
}
