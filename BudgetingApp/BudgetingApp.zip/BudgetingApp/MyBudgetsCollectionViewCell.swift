//
//  MyBudgetsCollectionViewCell.swift
//  BudgetingApp
//
//  Created by Janice Jung on 11/20/19.
//  Copyright © 2019 Janice Jung. All rights reserved.
//

import UIKit

class MyBudgetsCollectionViewCell: UICollectionViewCell {
    
    var amountLabel: UILabel!
    var categoryLabel: UILabel!
    
    override init(frame: CGRect) {
        super.init(frame: frame)
        
        backgroundColor = .lightGray
        layer.masksToBounds = true
        layer.cornerRadius = 6
        
        amountLabel = UILabel()
        amountLabel.font = UIFont.systemFont(ofSize: 15)
        amountLabel.sizeToFit()
        amountLabel.textColor = .black
        amountLabel.backgroundColor = .clear
        contentView.addSubview(amountLabel)
        
        categoryLabel = UILabel()
        categoryLabel.font = UIFont.boldSystemFont(ofSize: 20)
        categoryLabel.sizeToFit()
        categoryLabel.textColor = .black
        contentView.addSubview(categoryLabel)
        
        setupConstraints()
        
    }
    
    required init?(coder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    
    func setupConstraints() {
        categoryLabel.snp.makeConstraints { make in
            make.top.left.equalTo(contentView).offset(10)
        }
        
        amountLabel.snp.makeConstraints { make in
            make.left.equalTo(categoryLabel)
            make.top.equalTo(categoryLabel.snp.bottom).offset(10)
        }
    }
    
    func configure(for budget: Budget) {
        categoryLabel.text = budget.category
        amountLabel.text = budget.amount
    }
    
}


