//
//  MyBudgetsViewController.swift
//  BudgetingApp
//
//  Created by Janice Jung on 11/20/19.
//  Copyright © 2019 Janice Jung. All rights reserved.
//

import UIKit
import SnapKit

class MyBudgetsViewController: UIViewController {
    
    var budgetCollectionView: UICollectionView!
    var budgets: [Budget] = []
    var titleLabel: UILabel!
    var addButton: UIBarButtonItem!
    
    let budgetCellReuseIdentifier = "budgetCellReuseIdentifier"
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        addButton = UIBarButtonItem()
        addButton.title = "+"
        addButton.target = self
        addButton.action = #selector(pushSetBudgetViewController)
        navigationItem.rightBarButtonItem = addButton
        
        let budget1 = Budget(category: "Food", amount: "300")
        let budget2 = Budget(category: "Groceries", amount: "500")
        let budget3 = Budget(category: "Shopping", amount: "200")
        let budget4 = Budget(category: "Entertainment", amount: "100")
        let budget5 = Budget(category: "Groceries", amount: "500")
        let budget6 = Budget(category: "Transport", amount: "50")
        
        budgets = [budget1, budget2, budget3, budget4, budget5, budget6]
        
        title = "Budgets"
        view.backgroundColor = .white
        
        
        titleLabel = UILabel()
        titleLabel.text = "My Budgets"
        titleLabel.font = .systemFont(ofSize: 30)
        titleLabel.textAlignment = .center
        view.addSubview(titleLabel)
        
        let budgetLayout = UICollectionViewFlowLayout()
        budgetLayout.scrollDirection = .vertical
        budgetLayout.minimumLineSpacing = CGFloat(8)
        budgetLayout.minimumInteritemSpacing = CGFloat(8)
        
        budgetCollectionView = UICollectionView(frame: .zero, collectionViewLayout: budgetLayout)
        budgetCollectionView.backgroundColor = .white
        budgetCollectionView.register(MyBudgetsCollectionViewCell.self, forCellWithReuseIdentifier: budgetCellReuseIdentifier)
        budgetCollectionView.showsVerticalScrollIndicator = false
        budgetCollectionView.dataSource = self
        budgetCollectionView.delegate = self
        view.addSubview(budgetCollectionView)
        
        setupConstraints()
        
    }
    
    func setupConstraints() {
        
        titleLabel.snp.makeConstraints { make in
            make.top.left.right.equalTo(view.safeAreaLayoutGuide).offset(20)
        }
        
        budgetCollectionView.snp.makeConstraints { make in
            make.left.bottom.right.equalTo(view.safeAreaLayoutGuide).inset(UIEdgeInsets(top:0, left: 20, bottom: 20, right: 20))
            make.top.equalTo(titleLabel.snp.bottom).offset(20)
        }
        
    }
    
    @objc func pushSetBudgetViewController() {
        let viewController = SetBudgetViewController()
        //viewController.delegate = self
        navigationController?.pushViewController(viewController, animated: true)
    }

}

extension MyBudgetsViewController: UICollectionViewDataSource {
    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        return budgets.count
    }
    
    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
        
        let cell = budgetCollectionView.dequeueReusableCell(withReuseIdentifier: budgetCellReuseIdentifier, for: indexPath) as! MyBudgetsCollectionViewCell
        
        cell.configure(for: budgets[indexPath.row])
        return cell
    }
}

extension MyBudgetsViewController: UICollectionViewDelegateFlowLayout {
    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, sizeForItemAt indexPath: IndexPath) -> CGSize {
        let width = collectionView.frame.width
        return CGSize(width: width, height: 200)
    }
    
    
}

extension MyBudgetsViewController: UICollectionViewDelegate {
    func collectionView(_ collectionView: UICollectionView, didSelectItemAt indexPath: IndexPath) {
        let budget = budgets[indexPath.row]
        let budgetDetailViewController = BudgetDetailViewController(for: budget)
        navigationController?.pushViewController(budgetDetailViewController, animated: true)
    }
}
