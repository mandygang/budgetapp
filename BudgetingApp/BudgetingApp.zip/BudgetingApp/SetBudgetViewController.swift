//
//  SetBudgetViewController.swift
//  BudgetingApp
//
//  Created by Janice Jung on 11/20/19.
//  Copyright © 2019 Janice Jung. All rights reserved.
//

import UIKit

class SetBudgetViewController: UIViewController, UITextFieldDelegate {
    
    var categoryPicker: UIPickerView!
    var pickerData : [String] = []
    var newCategory: String?
    var newAmount: String?
    
    
    var categoryLabel: UILabel!
    var amountLabel: UILabel!
    var amountTextField: UITextField!
    var albumImageButton: UIButton!
    var saveButton: UIButton!
    var cancelButton: UIButton!

    override func viewDidLoad() {
        super.viewDidLoad()
        
        view.backgroundColor = .gray
        
        pickerData = ["Food", "Clothing", "Transport", "Entertainment", "Groceries", "Bills", "Other"]
        
        categoryPicker = UIPickerView()
        //categoryPicker.isHidden = true
        categoryPicker.delegate = self
        categoryPicker.backgroundColor = .cyan
        categoryPicker.dataSource = self
        categoryPicker.clipsToBounds = true
        view.addSubview(categoryPicker)
        
        amountTextField = UITextField()
        amountTextField.borderStyle = .roundedRect
        amountTextField.backgroundColor = UIColor(white: 0.3, alpha: 0.6)
        amountTextField.attributedPlaceholder = NSAttributedString(string: "1000")
        amountTextField.textColor = .black
        amountTextField.clearsOnBeginEditing = true
        amountTextField.layer.borderWidth = 1
        amountTextField.layer.cornerRadius = 4
        view.addSubview(amountTextField)
        
        
        
    }
    
    func setupConstraints() {
        categoryPicker.snp.makeConstraints { make in
            make.bottom.left.right.equalTo(view.safeAreaLayoutGuide)
        }
        
        amountTextField.snp.makeConstraints { make in
            make.centerX.equalTo(view.snp.centerX)
            make.centerY.equalTo(view.snp.centerY)
        }
    }
    
//    func textField(_ textField: UITextField, shouldChangeCharactersIn range: NSRange, replacementString string: String) -> Bool {
//       if let x = string.rangeOfCharacter(from: NSCharacterSet.decimalDigits) {
//          return true
//       } else {
//        return false
//        }
//    }

}

extension SetBudgetViewController: UIPickerViewDelegate, UIPickerViewDataSource {
    func numberOfComponents(in pickerView: UIPickerView) -> Int {
        return 1
    }
    
    func pickerView(_ pickerView: UIPickerView, numberOfRowsInComponent component: Int) -> Int {
        return pickerData.count
    }
    
    func pickerView(_ pickerView: UIPickerView, titleForRow row: Int, forComponent component: Int) -> String? {
        return pickerData[row]
    }
    
    func pickerView(_ pickerView: UIPickerView, didSelectRow row: Int, inComponent component: Int) {
        newCategory = pickerData[row]
    }
}
