//
//  User.swift
//  BudgetingApp
//
//  Created by Janice Jung on 11/20/19.
//  Copyright © 2019 Janice Jung. All rights reserved.
//

import Foundation

struct User: Codable {
    var token: String
}
