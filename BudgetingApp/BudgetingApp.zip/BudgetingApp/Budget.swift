//
//  Budget.swift
//  BudgetingApp
//
//  Created by Janice Jung on 11/20/19.
//  Copyright © 2019 Janice Jung. All rights reserved.
//

//enum Category: String {
//    case Food
//    case Entertainment
//    case Bills
//    case Groceries
//    case Shop
//    case Transport
//    case Other
//}

import Foundation

struct Budget: Codable {
    var amount: String
    var category: String
    
    init(category: String, amount: String) {
        self.category = category
        self.amount = amount
    }
    
}
