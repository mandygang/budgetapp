//
//  Expense.swift
//  BudgetingApp
//
//  Created by Janice Jung on 11/21/19.
//  Copyright © 2019 Janice Jung. All rights reserved.
//

import Foundation

struct Expense: Codable {
    var category: String
    var amount: String
    var note: String
    
    init(category: String, amount: String, note: String) {
        self.category = category
        self.amount = amount
        self.note = note
    }
    
}
